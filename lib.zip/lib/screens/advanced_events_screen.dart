import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/advanced_events_provider.dart';
import '../widgets/advanced_event_card.dart';
import '../widgets/event_search_bar.dart';
import '../widgets/event_stats_widget.dart';
import '../widgets/event_filters_modal.dart';
import '../widgets/floating_create_event_button.dart';
import '../theme/app_theme.dart';
import 'advanced_event_detail_screen.dart';

class AdvancedEventsScreen extends StatefulWidget {
  const AdvancedEventsScreen({Key? key}) : super(key: key);

  @override
  State<AdvancedEventsScreen> createState() => _AdvancedEventsScreenState();
}

class _AdvancedEventsScreenState extends State<AdvancedEventsScreen>
    with TickerProviderStateMixin {
  late TabController _tabController;
  final ScrollController _scrollController = ScrollController();

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.backgroundColor,
      body: CustomScrollView(
        controller: _scrollController,
        slivers: [
          _buildSliverAppBar(),
          _buildStatsSection(),
          _buildSearchSection(),
          _buildTabSection(),
          _buildEventsGrid(),
        ],
      ),
      floatingActionButton: const FloatingCreateEventButton(),
    );
  }

  Widget _buildSliverAppBar() {
    return SliverAppBar(
      expandedHeight: 120,
      floating: false,
      pinned: true,
      backgroundColor: AppTheme.primaryColor,
      flexibleSpace: FlexibleSpaceBar(
        title: const Text(
          'Eventos VMF',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 20,
          ),
        ),
        background: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              colors: [
                AppTheme.primaryColor,
                AppTheme.primaryColor.withValues(alpha: 0.8),
              ],
            ),
          ),
          child: const Center(
            child: Icon(
              Icons.event,
              size: 60,
              color: Colors.white24,
            ),
          ),
        ),
      ),
      actions: [
        IconButton(
          icon: const Icon(Icons.filter_list, color: Colors.white),
          onPressed: _showFiltersModal,
        ),
        IconButton(
          icon: const Icon(Icons.analytics, color: Colors.white),
          onPressed: _showAnalytics,
        ),
      ],
    );
  }

  Widget _buildStatsSection() {
    return SliverToBoxAdapter(
      child: Consumer<AdvancedEventsProvider>(
        builder: (context, provider, child) {
          return Container(
            margin: const EdgeInsets.all(16),
            child: EventStatsWidget(
              totalEvents: provider.totalEvents,
              upcomingEvents: provider.upcomingEvents,
              ongoingEvents: provider.ongoingEvents,
              totalAttendees: provider.totalAttendees,
            ),
          );
        },
      ),
    );
  }

  Widget _buildSearchSection() {
    return SliverToBoxAdapter(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Consumer<AdvancedEventsProvider>(
          builder: (context, provider, child) {
            return EventSearchBar(
              onSearch: provider.searchEvents,
              onClear: provider.clearFilters,
            );
          },
        ),
      ),
    );
  }

  Widget _buildTabSection() {
    return SliverToBoxAdapter(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withValues(alpha: 0.1),
              blurRadius: 8,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: TabBar(
          controller: _tabController,
          labelColor: AppTheme.primaryColor,
          unselectedLabelColor: Colors.grey,
          indicatorColor: AppTheme.primaryColor,
          indicatorWeight: 3,
          tabs: const [
            Tab(text: 'Todos'),
            Tab(text: 'Próximos'),
            Tab(text: 'En Curso'),
            Tab(text: 'Destacados'),
          ],
          onTap: (index) {
            final provider = Provider.of<AdvancedEventsProvider>(context, listen: false);
            switch (index) {
              case 0:
                provider.filterByStatus('Todos');
                break;
              case 1:
                provider.filterByStatus('Próximos');
                break;
              case 2:
                provider.filterByStatus('En curso');
                break;
              case 3:
                provider.clearFilters();
                break;
            }
          },
        ),
      ),
    );
  }

  Widget _buildEventsGrid() {
    return SliverPadding(
      padding: const EdgeInsets.all(16),
      sliver: Consumer<AdvancedEventsProvider>(
        builder: (context, provider, child) {
          if (provider.isLoading) {
            return const SliverFillRemaining(
              child: Center(
                child: CircularProgressIndicator(),
              ),
            );
          }

          if (provider.events.isEmpty) {
            return SliverFillRemaining(
              child: _buildEmptyState(),
            );
          }

          return SliverGrid(
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: _getCrossAxisCount(context),
              childAspectRatio: 0.75,
              crossAxisSpacing: 16,
              mainAxisSpacing: 16,
            ),
            delegate: SliverChildBuilderDelegate(
              (context, index) {
                final event = provider.events[index];
                return AdvancedEventCard(
                  event: event,
                  onTap: () => _navigateToEventDetail(event.id),
                );
              },
              childCount: provider.events.length,
            ),
          );
        },
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.event_busy,
            size: 80,
            color: Colors.grey[400],
          ),
          const SizedBox(height: 16),
          Text(
            'No hay eventos disponibles',
            style: TextStyle(
              fontSize: 18,
              color: Colors.grey[600],
              fontWeight: FontWeight.w500,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Crea tu primer evento o ajusta los filtros',
            style: TextStyle(
              fontSize: 14,
              color: Colors.grey[500],
            ),
          ),
          const SizedBox(height: 24),
          ElevatedButton.icon(
            onPressed: _showCreateEventDialog,
            icon: const Icon(Icons.add),
            label: const Text('Crear Evento'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.primaryColor,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(8),
              ),
            ),
          ),
        ],
      ),
    );
  }

  int _getCrossAxisCount(BuildContext context) {
    final width = MediaQuery.of(context).size.width;
    if (width > 1200) return 4;
    if (width > 800) return 3;
    if (width > 600) return 2;
    return 1;
  }

  void _navigateToEventDetail(String eventId) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => AdvancedEventDetailScreen(eventId: eventId),
      ),
    );
  }

  void _showFiltersModal() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => const EventFiltersModal(),
    );
  }

  void _showAnalytics() {
    final provider = Provider.of<AdvancedEventsProvider>(context, listen: false);
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Estadísticas Generales'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildStatRow('Total de eventos', provider.totalEvents.toString()),
              _buildStatRow('Eventos próximos', provider.upcomingEvents.toString()),
              _buildStatRow('Eventos en curso', provider.ongoingEvents.toString()),
              _buildStatRow('Eventos pasados', provider.pastEvents.toString()),
              const Divider(),
              _buildStatRow('Total asistentes', provider.totalAttendees.toString()),
              _buildStatRow('Promedio por evento', provider.averageAttendance.toStringAsFixed(1)),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cerrar'),
          ),
        ],
      ),
    );
  }

  Widget _buildStatRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label),
          Text(
            value,
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  void _showCreateEventDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Crear Nuevo Evento'),
        content: const Text(
          'La funcionalidad de creación de eventos estará disponible próximamente.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Entendido'),
          ),
        ],
      ),
    );
  }
}
